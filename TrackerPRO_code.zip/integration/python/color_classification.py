#!/usr/bin/env python

#The MIT License (MIT)
#Copyright (c) 2016 Massimiliano Patacchiola
#
#THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF 
#MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY 
#CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE 
#SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.

# [***]: visualize (cv2.imshow)

import cv2
import matplotlib.pyplot as plt
import numpy as np
import datetime
import os

class HistogramColorClassifier:
    """Classifier for comparing an image I with a model M. The comparison is based on color
    histograms. It included an implementation of the Histogram Intersection algorithm.

    The histogram intersection was proposed by Michael Swain and Dana Ballard 
    in their paper "Indexing via color histograms".
    Abstract: The color spectrum of multicolored objects provides a a robust, 
    efficient cue for indexing into a large database of models. This paper shows 
    color histograms to be stable object representations over change in view, and 
    demonstrates they can differentiate among a large number of objects. It introduces 
    a technique called Histogram Intersection for matching model and image histograms 
    and a fast incremental version of Histogram Intersection that allows real-time 
    indexing into a large database of stored models using standard vision hardware. 
    Color can also be used to search for the location of an object. An algorithm 
    called Histogram Backprojection performs this task efficiently in crowded scenes.
    """

    def __init__(self, channels=[0, 1, 2], hist_size=[10, 10, 10], hist_range=[0, 256, 0, 256, 0, 256], hist_type='BGR'):
        """Init the classifier.

        This class has an internal list containing all the models.
        it is possible to append new models. Using the default values
        it extracts a 3D BGR color histogram from the image, using
	10 bins per channel.
        @param channels list where we specify the index of the channel 
           we want to compute a histogram for. For a grayscale image, 
           the list would be [0]. For all three (red, green, blue) channels, 
           the channels list would be [0, 1, 2].
        @param hist_size number of bins we want to use when computing a histogram. 
            It is a list (one value for each channel). Note: the bin sizes can 
            be different for each channel.
        @param hist_range it is the min-max value of the values stored in the histogram.
            For three channels can be [0, 256, 0, 256, 0, 256], if there is only one
            channel can be [0, 256]
        @param hsv_type Convert the input BGR frame in HSV or GRAYSCALE. before taking 
            the histogram. The HSV representation can get more reliable results in 
            situations where light have a strong influence.
            BGR: (default) do not convert the input frame
            HSV: convert in HSV represantation
            GRAY: convert in grayscale
        """
        self.channels = channels
        self.hist_size = hist_size
        self.hist_range = hist_range
        self.hist_type = hist_type
        self.model_list = list()
        self.name_list = list()
        # # # # # # # # # # # # # # # # New ( particle model list ) # # # # # # # # # # # # # # # #
        self.particle_model_list = list()

    def addModelHistogram(self, model_frame, name=''):
        """Add the histogram to internal container. If the name of the object
           is already present then replace that histogram with a new one.

        @param model_frame the frame to add to the model, its histogram
            is obtained and saved in internal list.
        @param name a string representing the name of the model.
            If nothing is specified then the name will be the index of the element.
        """

        if (self.hist_type == 'HSV'): model_frame = cv2.cvtColor(model_frame, cv2.COLOR_BGR2HSV)
        elif (self.hist_type == 'GRAY'): model_frame = cv2.cvtColor(model_frame, cv2.COLOR_BGR2GRAY)
        elif (self.hist_type == 'RGB'): model_frame = cv2.cvtColor(model_frame, cv2.COLOR_BGR2RGB)
        hist = cv2.calcHist([model_frame], self.channels, None, self.hist_size, self.hist_range)
        hist = cv2.normalize(hist, hist).flatten()
        if name == '': name = str(len(self.model_list))
        if name not in self.name_list:
            self.model_list.append(hist)
            self.name_list.append(name)
        else:
            for i in range(len(self.name_list)):
                if self.name_list[i] == name:
                    self.model_list[i] = hist
                    break

    # # object vs particles compare histogram distance [***]
    def returnInitObjectParticleHistogramComparisonArray(self, image, region, particles, idx, method='bhattacharyya'):

        obj_frame_copy = image.copy() 
        obj_particle_copy = image.copy()

        obj_frame_copy = cv2.cvtColor(obj_frame_copy, cv2.COLOR_BGR2HSV)
        obj_particle_copy = cv2.cvtColor(obj_particle_copy, cv2.COLOR_BGR2HSV)

        # elif (self.hist_type == 'GRAY'):
        #     face_frame_copy = cv2.cvtColor(model_frame, cv2.COLOR_BGR2GRAY)
        #     face_particle_copy = cv2.cvtColor(model_frame, cv2.COLOR_BGR2HSV)
        # elif (self.hist_type == 'RGB'):
        #     face_frame_copy = cv2.cvtColor(model_frame, cv2.COLOR_BGR2RGB)
        #     face_particle_copy = cv2.cvtColor(model_frame, cv2.COLOR_BGR2HSV)

        # # Cropping face region
        x = int(region.x)
        y = int(region.y)
        w = int(region.width)
        h = int(region.height)

        cropped_obj_img = obj_frame_copy[y:y + h, x:x + w]
        # # H S V --> V S H 상태임 다시 H S V로 변환 필요
        obj_crop_v, obj_crop_s, obj_crop_h = cv2.split(cropped_obj_img)
        inverse_cropped_obj_img = cv2.merge((obj_crop_h, obj_crop_s, obj_crop_v))

        # # 우리는 HSV 이미지에서, 파티클 좌표에서 HSV 값만 추출하기를 원한다.
        # # 히스토그램 그릴 때 범위 0~128 (255 x)
        image = np.zeros(shape=obj_particle_copy.shape, dtype=np.uint8)
        # # white-255,255,255, black-0,0,0
        image.fill(255)

        x_ = int(region.x)
        y_ = int(region.y)
        w_ = int(region.width)
        h_ = int(region.height)
        
        # # [0] [1] [2]: channel value (R G B) or (H S V)
        # # 좌표값 접근 image[y,x]       
        for i in range(particles.shape[0]):
            # # [[x y]
            # #  [. .]]
            # print(particles[i])
            x_point = particles[i][0]
            y_point = particles[i][1]
            # print(x_point)
            # print(y_point)
            (h, s, v) = obj_particle_copy[y_point, x_point]
            image[y_point, x_point] = (h, s, v)
            # print("PREV HSV: ", image[y_point, x_point])

        cropped_particle_img = image[y_:y_ + h_, x_:x_ + w_]
        # # H S V --> V S H 상태임 다시 H S V로 변환 필요
        particle_crop_v, particle_crop_s, particle_crop_h = cv2.split(cropped_particle_img)
        inverse_cropped_particle_img = cv2.merge((particle_crop_h, particle_crop_s, particle_crop_v))
        
        suffix = datetime.datetime.now().strftime("%H%M%S")
         
        hist_obj = cv2.calcHist([inverse_cropped_obj_img], self.channels, None, self.hist_size, self.hist_range)
        hist_obj = cv2.normalize(hist_obj, hist_obj).flatten()

        hist_particle = cv2.calcHist([inverse_cropped_particle_img], self.channels, None, self.hist_size,
                                     self.hist_range)
        hist_particle = cv2.normalize(hist_particle, hist_particle).flatten()

        comparison_array = self.returnHistogramComparison(hist_obj, hist_particle, method=method)
        comp_str = '%.2f' % comparison_array
        
        if not os.path.exists("/mnt/nvme1/dhlee/PycharmProjects/vots2023/tests/init/img/"):
                os.makedirs("/mnt/nvme1/dhlee/PycharmProjects/vots2023/tests/init/img/")
        if not os.path.exists("/mnt/nvme1/dhlee/PycharmProjects/vots2023/tests/init/particle/"):
                os.makedirs("/mnt/nvme1/dhlee/PycharmProjects/vots2023/tests/init/particle/")
                
        img_name = "/mnt/nvme1/dhlee/PycharmProjects/vots2023/tests/init/img/img"+str(idx)+"_"+comp_str+"_"+str(suffix)+".jpg"
        particle_name = "/mnt/nvme1/dhlee/PycharmProjects/vots2023/tests/init/particle/particle_img"+str(idx)+"_"+comp_str+"_"+str(suffix)+".jpg"
                       
        cv2.imwrite(img_name, inverse_cropped_obj_img)
        cv2.imwrite(particle_name, inverse_cropped_particle_img)
        
        return comparison_array
    
    # # (in def track) object vs particles compare histogram distance [***]
    def returnObjectParticleHistogramComparisonArray(self, image, region, particles, idx, frame_idx, img_content, flag, method='bhattacharyya'):
        obj_frame_copy = image.copy() 
        obj_particle_copy = image.copy()

        obj_frame_copy = cv2.cvtColor(obj_frame_copy, cv2.COLOR_BGR2HSV)
        obj_particle_copy = cv2.cvtColor(obj_particle_copy, cv2.COLOR_BGR2HSV)

        # elif (self.hist_type == 'GRAY'):
        #     face_frame_copy = cv2.cvtColor(model_frame, cv2.COLOR_BGR2GRAY)
        #     face_particle_copy = cv2.cvtColor(model_frame, cv2.COLOR_BGR2HSV)
        # elif (self.hist_type == 'RGB'):
        #     face_frame_copy = cv2.cvtColor(model_frame, cv2.COLOR_BGR2RGB)
        #     face_particle_copy = cv2.cvtColor(model_frame, cv2.COLOR_BGR2HSV)

        # # Cropping face region
        x = int(region[0])
        y = int(region[1])
        w = int(region[2])
        h = int(region[3])
        
        cropped_obj_img = obj_frame_copy[y:y + h, x:x + w]
        # # H S V --> V S H 상태임 다시 H S V로 변환 필요
        obj_crop_v, obj_crop_s, obj_crop_h = cv2.split(cropped_obj_img)
        inverse_cropped_obj_img = cv2.merge((obj_crop_h, obj_crop_s, obj_crop_v))

        # # 우리는 HSV 이미지에서, 파티클 좌표에서 HSV 값만 추출하기를 원한다.
        # # 히스토그램 그릴 때 범위 0~128 (255 x)
        image_particle = np.zeros(shape=obj_particle_copy.shape, dtype=np.uint8)
        # # white-255,255,255, black-0,0,0
        image_particle.fill(255)

        x_ = int(region[0])
        y_ = int(region[1])
        w_ = int(region[2])
        h_ = int(region[3])
        
        # # [0] [1] [2]: channel value (R G B) or (H S V)
        # # 좌표값 접근 image[y,x]
        for i in range(particles.shape[0]):
            # # [[x y]
            # #  [. .]]
            # print(particles[i])
            x_point = particles[i][0]
            y_point = particles[i][1]

            if x_point < 0 or x_point > image_particle.shape[1]-1:
                print("Exception_X:", x_point)
            if y_point < 0 or y_point > image_particle.shape[0]-1:
                print("Exception_Y:", y_point)
            
            (h, s, v) = obj_particle_copy[y_point, x_point]
            image_particle[y_point, x_point] = (h, s, v)
            # print("PREV HSV: ", image[y_point, x_point])

        cropped_particle_img = image_particle[y_:y_ + h_, x_:x_ + w_]
        # # H S V --> V S H 상태임 다시 H S V로 변환 필요
        particle_crop_v, particle_crop_s, particle_crop_h = cv2.split(cropped_particle_img)
        inverse_cropped_particle_img = cv2.merge((particle_crop_h, particle_crop_s, particle_crop_v))

        hist_obj = cv2.calcHist([inverse_cropped_obj_img], self.channels, None, self.hist_size, self.hist_range)
        hist_obj = cv2.normalize(hist_obj, hist_obj).flatten()

        hist_particle = cv2.calcHist([inverse_cropped_particle_img], self.channels, None, self.hist_size,
                                     self.hist_range)
        hist_particle = cv2.normalize(hist_particle, hist_particle).flatten()

        comparison_array = self.returnHistogramComparison(hist_obj, hist_particle, method=method)
        comp_str = '%.2f' % comparison_array
        
        suffix = datetime.datetime.now().strftime("%H%M%S")
        
        if flag == 1:
            if not os.path.exists("/mnt/nvme1/dhlee/PycharmProjects/vots2023/tests/flag1/"+img_content+"/img/"):
                os.makedirs("/mnt/nvme1/dhlee/PycharmProjects/vots2023/tests/flag1/"+img_content+"/img/")
            if not os.path.exists("/mnt/nvme1/dhlee/PycharmProjects/vots2023/tests/flag1/"+img_content+"/particle/"):
                os.makedirs("/mnt/nvme1/dhlee/PycharmProjects/vots2023/tests/flag1/"+img_content+"/particle/")
                   
            img_name = "/mnt/nvme1/dhlee/PycharmProjects/vots2023/tests/flag1/"+img_content+"/img/img"+str(frame_idx)+"_"+str(idx)+"_"+comp_str+"_"+str(suffix)+".jpg"
            particle_name = "/mnt/nvme1/dhlee/PycharmProjects/vots2023/tests/flag1/"+img_content+"/particle/particle_img"+str(frame_idx)+"_"+str(idx)+"_"+comp_str+"_"+str(suffix)+".jpg"    
            cv2.imwrite(img_name, inverse_cropped_obj_img)
            cv2.imwrite(particle_name, inverse_cropped_particle_img)    
        # # # # # # # # # # Particle contraction # # # # # # # # # # # # # # # # # # # # # # # # # #        
        elif flag == 2:
            if not os.path.exists("/mnt/nvme1/dhlee/PycharmProjects/vots2023/tests/flag2/"+img_content+"/img_"+str(idx)+"/"):
                os.makedirs("/mnt/nvme1/dhlee/PycharmProjects/vots2023/tests/flag2/"+img_content+"/img_"+str(idx)+"/")
            if not os.path.exists("/mnt/nvme1/dhlee/PycharmProjects/vots2023/tests/flag2/"+img_content+"/particle_"+str(idx)+"/"):
                os.makedirs("/mnt/nvme1/dhlee/PycharmProjects/vots2023/tests/flag2/"+img_content+"/particle_"+str(idx)+"/")
        
            img_name = "/mnt/nvme1/dhlee/PycharmProjects/vots2023/tests/flag2/"+img_content+"/img_"+str(idx)+"/img"+str(frame_idx)+"_"+comp_str+"_"+str(suffix)+".jpg"
            particle_name = "/mnt/nvme1/dhlee/PycharmProjects/vots2023/tests/flag2/"+img_content+"/particle_"+str(idx)+"/particleimg"+str(frame_idx)+"_"+comp_str+"_"+str(suffix)+".jpg"
            cv2.imwrite(img_name, inverse_cropped_obj_img)
            cv2.imwrite(particle_name, inverse_cropped_particle_img)
        # # # # # # # # # # Particle dilation # # # # # # # # # # # # # # # # # # # # # # # # # #        
        elif flag == 3:
            if not os.path.exists("/mnt/nvme1/dhlee/PycharmProjects/vots2023/tests/flag3/"+img_content+"/img_"+str(idx)+"/"):
                os.makedirs("/mnt/nvme1/dhlee/PycharmProjects/vots2023/tests/flag3/"+img_content+"/img_"+str(idx)+"/")
            if not os.path.exists("/mnt/nvme1/dhlee/PycharmProjects/vots2023/tests/flag3/"+img_content+"/particle_"+str(idx)+"/"):
                os.makedirs("/mnt/nvme1/dhlee/PycharmProjects/vots2023/tests/flag3/"+img_content+"/particle_"+str(idx)+"/")
        
            img_name = "/mnt/nvme1/dhlee/PycharmProjects/vots2023/tests/flag3/"+img_content+"/img_"+str(idx)+"/img"+str(frame_idx)+"_"+comp_str+"_"+str(suffix)+".jpg"
            particle_name = "/mnt/nvme1/dhlee/PycharmProjects/vots2023/tests/flag3/"+img_content+"/particle_"+str(idx)+"/particleimg"+str(frame_idx)+"_"+comp_str+"_"+str(suffix)+".jpg"
            cv2.imwrite(img_name, inverse_cropped_obj_img)
            cv2.imwrite(particle_name, inverse_cropped_particle_img)
        # # # # # # # # # # Match success # # # # # # # # # # # # # # # # # # # # # # # # # #    
        elif flag == 4:
            if not os.path.exists("/mnt/nvme1/dhlee/PycharmProjects/vots2023/tests/flag4/"+img_content+"/img_"+str(idx)+"/"):
                os.makedirs("/mnt/nvme1/dhlee/PycharmProjects/vots2023/tests/flag4/"+img_content+"/img_"+str(idx)+"/")
            if not os.path.exists("/mnt/nvme1/dhlee/PycharmProjects/vots2023/tests/flag4/"+img_content+"/particle_"+str(idx)+"/"):
                os.makedirs("/mnt/nvme1/dhlee/PycharmProjects/vots2023/tests/flag4/"+img_content+"/particle_"+str(idx)+"/")
        
            img_name = "/mnt/nvme1/dhlee/PycharmProjects/vots2023/tests/flag4/"+img_content+"/img_"+str(idx)+"/img"+str(frame_idx)+"_"+comp_str+"_"+str(suffix)+".jpg"
            particle_name = "/mnt/nvme1/dhlee/PycharmProjects/vots2023/tests/flag4/"+img_content+"/particle_"+str(idx)+"/particleimg"+str(frame_idx)+"_"+comp_str+"_"+str(suffix)+".jpg"
            cv2.imwrite(img_name, inverse_cropped_obj_img)
            cv2.imwrite(particle_name, inverse_cropped_particle_img)

        return comparison_array

        # # (in def track) object vs particles compare histogram distance [***]
    def returnAllObjectParticleHistogramComparisonArray(self, image, region, particles, idx, subframeidx, frame_idx, img_content, flag, method='bhattacharyya'):
        obj_frame_copy = image.copy()
        obj_particle_copy = image.copy()

        obj_frame_copy = cv2.cvtColor(obj_frame_copy, cv2.COLOR_BGR2HSV)
        obj_particle_copy = cv2.cvtColor(obj_particle_copy, cv2.COLOR_BGR2HSV)

        # elif (self.hist_type == 'GRAY'):
        #     face_frame_copy = cv2.cvtColor(model_frame, cv2.COLOR_BGR2GRAY)
        #     face_particle_copy = cv2.cvtColor(model_frame, cv2.COLOR_BGR2HSV)
        # elif (self.hist_type == 'RGB'):
        #     face_frame_copy = cv2.cvtColor(model_frame, cv2.COLOR_BGR2RGB)
        #     face_particle_copy = cv2.cvtColor(model_frame, cv2.COLOR_BGR2HSV)

        # # Cropping face region
        x = int(region[0])
        y = int(region[1])
        w = int(region[2])
        h = int(region[3])

        cropped_obj_img = obj_frame_copy[y:y + h, x:x + w]
        # # H S V --> V S H 상태임 다시 H S V로 변환 필요
        obj_crop_v, obj_crop_s, obj_crop_h = cv2.split(cropped_obj_img)
        inverse_cropped_obj_img = cv2.merge((obj_crop_h, obj_crop_s, obj_crop_v))

        # # 우리는 HSV 이미지에서, 파티클 좌표에서 HSV 값만 추출하기를 원한다.
        # # 히스토그램 그릴 때 범위 0~128 (255 x)
        image_particle = np.zeros(shape=obj_particle_copy.shape, dtype=np.uint8)
        # # white-255,255,255, black-0,0,0
        image_particle.fill(255)

        x_ = int(region[0])
        y_ = int(region[1])
        w_ = int(region[2])
        h_ = int(region[3])

        # # [0] [1] [2]: channel value (R G B) or (H S V)
        # # 좌표값 접근 image[y,x]
        for i in range(particles.shape[0]):
            # # [[x y]
            # #  [. .]]
            # print(particles[i])
            x_point = particles[i][0]
            y_point = particles[i][1]

            if x_point < 0 or x_point > image_particle.shape[1]-1:
                print("Exception_X:", x_point)
            if y_point < 0 or y_point > image_particle.shape[0]-1:
                print("Exception_Y:", y_point)

            (h, s, v) = obj_particle_copy[y_point, x_point]
            image_particle[y_point, x_point] = (h, s, v)
            # print("PREV HSV: ", image[y_point, x_point])

        cropped_particle_img = image_particle[y_:y_ + h_, x_:x_ + w_]
        # # H S V --> V S H 상태임 다시 H S V로 변환 필요
        particle_crop_v, particle_crop_s, particle_crop_h = cv2.split(cropped_particle_img)
        inverse_cropped_particle_img = cv2.merge((particle_crop_h, particle_crop_s, particle_crop_v))

        hist_obj = cv2.calcHist([inverse_cropped_obj_img], self.channels, None, self.hist_size, self.hist_range)
        hist_obj = cv2.normalize(hist_obj, hist_obj).flatten()

        hist_particle = cv2.calcHist([inverse_cropped_particle_img], self.channels, None, self.hist_size,
                                     self.hist_range)
        hist_particle = cv2.normalize(hist_particle, hist_particle).flatten()

        comparison_array = self.returnHistogramComparison(hist_obj, hist_particle, method=method)
        comp_str = '%.2f' % comparison_array

        suffix = datetime.datetime.now().strftime("%H%M%S")

        if flag == 1:
            if not os.path.exists("/mnt/nvme1/dhlee/PycharmProjects/vots2023/tests/flag1/"+img_content+"/img_"+str(idx)+"/"):
                os.makedirs("/mnt/nvme1/dhlee/PycharmProjects/vots2023/tests/flag1/"+img_content+"/img_"+str(idx)+"/")
            if not os.path.exists("/mnt/nvme1/dhlee/PycharmProjects/vots2023/tests/flag1/"+img_content+"/particle_"+str(idx)+"/"):
                os.makedirs("/mnt/nvme1/dhlee/PycharmProjects/vots2023/tests/flag1/"+img_content+"/particle_"+str(idx)+"/")
        
            img_name = "/mnt/nvme1/dhlee/PycharmProjects/vots2023/tests/flag1/"+img_content+"/img_"+str(idx)+"/img"+str(frame_idx)+"_"+subframeidx+"_"+comp_str+"_"+str(suffix)+".jpg"
            particle_name = "/mnt/nvme1/dhlee/PycharmProjects/vots2023/tests/flag1/"+img_content+"/particle_"+str(idx)+"/particleimg"+str(frame_idx)+"_"+subframeidx+"_"+comp_str+"_"+str(suffix)+".jpg"
            cv2.imwrite(img_name, inverse_cropped_obj_img)
            cv2.imwrite(particle_name, inverse_cropped_particle_img)
            # # # # # # # # # # Particle success # # # # # # # # # # # # # # # # # # # # # # # # # #

        return comparison_array

    # # matched object vs init object histogram distance [***]
    def returnObjectoObjectDistance(self, now_obj, init_obj, idx, frame_idx, method="bhattacharyya"):

        # # Init feature
        # # H S V --> V S H 상태임 다시 H S V로 변환 필요
        init_obj = cv2.cvtColor(init_obj, cv2.COLOR_BGR2HSV)
        init_crop_v, init_crop_s, init_crop_h = cv2.split(init_obj)
        init_obj_img = cv2.merge((init_crop_h, init_crop_s, init_crop_v))

        hist_init_obj = cv2.calcHist([init_obj_img], self.channels, None, self.hist_size, self.hist_range)
        hist_init_obj = cv2.normalize(hist_init_obj, hist_init_obj).flatten()
        
        # # Now feature
        # # H S V --> V S H 상태임 다시 H S V로 변환 필요
        now_obj = cv2.cvtColor(now_obj, cv2.COLOR_BGR2HSV)
        now_crop_v, now_crop_s, now_crop_h = cv2.split(now_obj)
        now_obj_img = cv2.merge((now_crop_h, now_crop_s, now_crop_v))

        hist_now_obj = cv2.calcHist([now_obj_img], self.channels, None, self.hist_size, self.hist_range)
        hist_now_obj = cv2.normalize(hist_now_obj, hist_now_obj).flatten()

        comparison_array = self.returnHistogramComparison(hist_now_obj, hist_init_obj, method=method)
        comp_str = '%.2f' % comparison_array

        #cv2.imwrite("/home/user/PycharmProjects/vots2023/test_img_f5/now_object_img"+str(frame_idx)+"_"+str(idx)+"_"+comp_str+".jpg", now_obj_img)
        #cv2.imwrite("/home/user/PycharmProjects/vots2023/test_img_f5/init_object_img"+str(frame_idx)+"_"+str(idx)+"_"+comp_str+".jpg", init_obj_img)

        return comparison_array

    def returnHistogramComparison(self, hist_1, hist_2, method='bhattacharyya'):
        """Return the comparison value of two histograms.

        Comparing an histogram with itself return 1.
        @param hist_1
        @param hist_2
        @param method the comparison method.
            intersection: (default) the histogram intersection (Swain, Ballard)

        intersection, correlation: high is good
        chisqr, bhattacharyya: low is good
        """
        if cv2.__version__.split(".")[0] == '4':
            if(method=="intersection"):
                comparison = cv2.compareHist(hist_1, hist_2, cv2.HISTCMP_INTERSECT)
            elif(method=="correlation"):
                comparison = cv2.compareHist(hist_1, hist_2, cv2.HISTCMP_CORREL)
            elif(method=="chisqr"):
                comparison = cv2.compareHist(hist_1, hist_2, cv2.HISTCMP_CHISQR)
            elif(method=="bhattacharyya"):
                comparison = cv2.compareHist(hist_1, hist_2, cv2.HISTCMP_BHATTACHARYYA)
            else:
                raise ValueError('[DEEPGAZE] color_classification.py: the method specified ' + str(method) + ' is not supported.')
        else:
            if(method=="intersection"):
                comparison = cv2.compareHist(hist_1, hist_2, cv2.cv.CV_COMP_INTERSECT)
            elif(method=="correlation"):
                comparison = cv2.compareHist(hist_1, hist_2, cv2.cv.CV_COMP_CORREL)
            elif(method=="chisqr"):
                comparison = cv2.compareHist(hist_1, hist_2, cv2.cv.CV_COMP_CHISQR)
            elif(method=="bhattacharyya"):
                comparison = cv2.compareHist(hist_1, hist_2, cv2.cv.CV_COMP_BHATTACHARYYA)
            else:
                raise ValueError('[DEEPGAZE] color_classification.py: the method specified ' + str(method) + ' is not supported.')
        return comparison

    def returnHistogramComparisonProbability(self, image, method='bhattacharyya'):
        """Return the probability distribution of the comparison between 
        all the model and the input image. The sum of the elements in the output
        array sum up to 1.

        The highest value represents the best match.
        @param image the image to compare
        @param method the comparison method.
            intersection: (default) the histogram intersection (Swain, Ballard)
        @return a numpy array containg the comparison value between each pair image-model
        """
        comparison_array = self.returnHistogramComparisonArray(image=image, method=method)
        #comparison_array[comparison_array < 0] = 0 #Remove negative values
        comparison_distribution = np.divide(comparison_array, np.sum(comparison_array))
        return comparison_distribution

    def returnBestMatchIndex(self, image, method='bhattacharyya'):
        """Return the index of the best match between the image and the internal models.

        @param image the image to compare
        @param method the comparison method.
            intersection: (default) the histogram intersection (Swain, Ballard)
        @return a numpy array containg the comparison value between each pair image-model
        """
        comparison_array = self.returnHistogramComparisonArray(image, method=method)
        return np.argmax(comparison_array)

    def returnBestMatchName(self, image, method='bhattacharyya'):
        """Return the name of the best match between the image and the internal models.

        @param image the image to compare
        @param method the comparison method.
            intersection: (default) the histogram intersection (Swain, Ballard)
        @return a string representing the name of the best matching model
        """
        comparison_array = self.returnHistogramComparisonArray(image, method=method)
        arg_max = np.argmax(comparison_array)
        return self.name_list[arg_max]

    def returnNameList(self):
        """Return a list containing all the names stored in the model.

        @return: a list containing the name of the models.
        """
        return self.name_list

    def returnSize(self):
        """Return the number of elements stored.

        @return: an integer representing the number of elements stored
        """
        return len(self.model_list)
