#!/usr/bin/env python

# The MIT License (MIT)
# Copyright (c) 2016 Massimiliano Patacchiola
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
# MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY
# CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE
# SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.


# Thank to rlabbe and his fantastic repository for Bayesian Filter:
# https://github.com/rlabbe/Kalman-and-Bayesian-Filters-in-Python

import numpy as np
from numpy.random import uniform
from numpy.random import normal
import cv2
import sys
import math
import random



class ParticleFilter:
    """Particle filter motion tracking.
    This class estimates the position of a single point in a image.
    It can be used to predict the position of a landmark
    for example when tracking some face features, or to track the corner of a bounding box.
    """

    def __init__(self, position, N, frame):
        """Init the particle filter.
        @param position object: [position[0](=center x), position[1](=center y), size[0], size[1]]
        @param N the number of particles
        @param FN the shape of frame
        """
        # # Not Init. particle case
        if (N <= 0):
            raise ValueError(
                '[DEEPGAZE] motion_tracking.py: the ParticleFilter class does not accept a value of N which is <= 0 or >(widht*height)')
        self.frame_width = frame[1]
        self.frame_height = frame[0]
        
        self.left = max(round(position[0] - position[2] / 2), 0)
        self.top = max(round(position[1] - position[3] / 2), 0)
        self.right = min(self.left + position[2], self.frame_width - 1)
        self.bottom = min(self.top + position[3], self.frame_height - 1)
        self.position = position
        
        # # # # # # # # # # # # # # # # # # # # # # # # create_uniform_particles # # # # # # # # # # # # # # # # # # # #
        """
        self.particles = np.empty((N, 2))
        self.particles[:, 0] = uniform(self.left, position[0] + position[2], size=N)  # init the X coord
        self.particles[:, 1] = uniform(self.top, position[1] + position[3], size=N)  # init the Y coord
                
        # # Init the weiths vector as a uniform distribution
        # # at the begining each particle has the same probability
        # # to represent the point we are following
        self.weights = np.empty((N, 1))
        self.weights = np.array([1.0 / N] * N)
        """
        # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # #
        # # # # # # # # # # # # # # # # # # # # # # # # create_circular_uniform_particles # # # # # # # # # # # # # # # 
        
        R = int(min(self.position[2] / 2, self.position[3] / 2))
        
        xcenter = self.position[0]
        ycenter = self.position[1]
        self.particles = np.empty((N, 2))
        
        """        
        half_N = int(N/2)
        R2 = int(self.position[3] / 2)
        
        radius = R * np.sqrt(np.random.rand(half_N, 1))
        theta = 2 * np.pi * np.random.rand(half_N, 1)
        
        x_points = radius * np.cos(theta)
        y_points = radius * np.sin(theta)
                
        radius2 = R2 * np.sqrt(np.random.rand(half_N, 1))
        theta2 = 2 * np.pi * np.random.rand(half_N, 1)
        
        # # swap x,y?
        x2_points = radius2 * np.cos(theta2)
        y2_points = radius2 * np.sin(theta2)
        
        self.particles[:, 0] = np.concatenate([x_points.flatten(), x2_points.flatten()])
        self.particles[:, 1] = np.concatenate([y_points.flatten(), y2_points.flatten()])
        """
        
        radius = R * np.sqrt(np.random.rand(N, 1))
        theta = 2 * np.pi * np.random.rand(N, 1)
        x_points = radius * np.cos(theta)
        y_points = radius * np.sin(theta)
        
        self.particles[:, 0] = x_points.flatten()
        self.particles[:, 1] = y_points.flatten()
        
        self.particles[:, 0:1] += position[0]
        self.particles[:, 1:2] += position[1]        
        
        self.weights = np.empty((N, 1))
        self.weights = np.array([1.0 / N] * N)   
        
        # # Exception Case (out of position box) --> mapping to center
        for i in range(self.particles.shape[0]):
            # # X position left 넘은 경우            
            if self.particles[:, 0][i] <= self.left:
                self.particles[:, 0][i] = self.position[0]
            # # X position right 넘은 경우
            elif self.particles[:, 0][i] >= self.right:
                self.particles[:, 0][i] = self.position[0]
            # # Y position top 넘은 경우
            elif self.particles[:, 1][i] <= self.top:
                self.particles[:, 1][i] = self.position[1]
            # # Y방향 아래 넘은 경우
            elif self.particles[:, 1][i] >= self.bottom:
                self.particles[:, 1][i] = self.position[1]  
        
        # # over frame check
        for j in range(self.particles.shape[0]):
            # # X position left 넘은 경우            
            if self.particles[:, 0][j] < 0:
                self.particles[:, 0][j] = 0
            # # X position right 넘은 경우
            elif self.particles[:, 0][j] > self.frame_width - 1:
                self.particles[:, 0][j] = self.frame_width - 1
            # # Y position top 넘은 경우
            elif self.particles[:, 1][j] < 0:
                self.particles[:, 1][j] = 0
            # # Y방향 아래 넘은 경우
            elif self.particles[:, 1][j] > self.frame_height - 1:
                self.particles[:, 1][j] = self.frame_height - 1
                        
        # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # #           
        # # # # # # # # # # # # # # # # # # # # # # # # create_gaussian_particles # # # # # # # # # # # # # # # # # # #
        """
        self.particles = np.empty((N, 2))
        self.particles[:, 0] = normal(0, 1, size=N) # init the X coord
        self.particles[:, 1] = normal(0, 1, size=N) # init the Y coord

        # # move init X,Y particles to object center box
        self.particles[:, 0:1] += position[0]
        self.particles[:, 1:2] += position[1]

        # # 1d gaussian, (particles, sigma)
        gaussian_kernel = cv2.getGaussianKernel(N, 1)
        gaussian_kernel = gaussian_kernel.flatten()
        self.weights = gaussian_kernel
        """
        # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # #
        # print("INIT PARTICLES: ", self.particles)
        # print("INIT WEIGHTS: ", self.weights)
        # print("INIT PARTICLES: ", self.particles.shape)
        # print("INIT WEIGHTS: ", self.weights.shape)
        # self.weights.fill(1.0/N) #normalised values
  
    def predict(self, x_velocity, y_velocity, std):
        """Predict the position of the point(particles coord) in the next frame.
        Move the particles based on how the real system is predicted to behave.

        The position of the point at the next time step is predicted using the
        estimated velocity along X and Y axis and adding Gaussian noise sampled
        from a distribution with MEAN=0.0 and STD=std. It is a linear model.
        @param x_velocity the velocity of the object along the X axis in terms of pixels/frame
        @param y_velocity the velocity of the object along the Y axis in terms of pixels/frame
        @param std the standard deviation of the gaussian distribution used to add noise
        """
        # # To predict the position of the point at the next step we take the
        # # previous position and we add the estimated speed and Gaussian noise
        self.particles[:, 0] += x_velocity + (np.random.randn(len(self.particles)) * std)  # predict the X coord
        self.particles[:, 1] += y_velocity + (np.random.randn(len(self.particles)) * std)  # predict the Y coord
        # print(np.random.randn(len(self.particles)) * std)

        # # Particles len.
        # print(self.particles.shape[0])

        # print(self.frame_width)
        # print(self.frame_height)
        
        # # Exception Case (out of position box) --> mapping to center
        for i in range(self.particles.shape[0]):
            # # X position left 넘은 경우            
            if self.particles[:, 0][i] <= self.left:
                self.particles[:, 0][i] = self.position[0]
            # # X position right 넘은 경우
            elif self.particles[:, 0][i] >= self.right:
                self.particles[:, 0][i] = self.position[0]
            # # Y position top 넘은 경우
            elif self.particles[:, 1][i] <= self.top:
                self.particles[:, 1][i] = self.position[1]
            # # Y방향 아래 넘은 경우
            elif self.particles[:, 1][i] >= self.bottom:
                self.particles[:, 1][i] = self.position[1]   

        # # over frame check
        for j in range(self.particles.shape[0]):
            # # X position left 넘은 경우            
            if self.particles[:, 0][j] < 0:
                self.particles[:, 0][j] = 0
            # # X position right 넘은 경우
            elif self.particles[:, 0][j] > self.frame_width - 1:
                self.particles[:, 0][j] = self.frame_width - 1
            # # Y position top 넘은 경우
            elif self.particles[:, 1][j] < 0:
                self.particles[:, 1][j] = 0
            # # Y방향 아래 넘은 경우
            elif self.particles[:, 1][j] > self.frame_height - 1:
                self.particles[:, 1][j] = self.frame_height - 1

    def estimate(self):
        """Estimate the position of the point given the particle weights.

        This function get the mean and variance associated with the point to estimate.
        @return get the x_mean, y_mean and the x_var, y_var
        """
        # # Using the weighted average of the particles
        # # gives an estimation of the position of the point
        x_mean = np.average(self.particles[:, 0], weights=self.weights, axis=0).astype(int)
        y_mean = np.average(self.particles[:, 1], weights=self.weights, axis=0).astype(int)

        # mean = np.average(self.particles[:, 0:2], weights=self.weights, axis=0)
        # var  = np.average((self.particles[:, 0:2] - mean)**2, weights=self.weights, axis=0)
        # x_mean = int(mean[0])
        # y_mean = int(mean[1])
        # x_var = int(var[0])
        # y_var = int(var[1])
        return x_mean, y_mean, 0, 0

    def update(self, x, y):
        """Update the weights associated which each particle based on the (x,y) coords measured.
        Particles that closely match the measurements give an higher contribution.

        The position of the point at the next time step is predicted using the
        estimated speed along X and Y axis and adding Gaussian noise sampled
        from a distribution with MEAN=0.0 and STD=std. It is a linear model.
        @param x the position of the point in the X axis
        @param y the position of the point in the Y axis
        @param
        """
        # # Generating a temporary array for the input position (center coord)
        position = np.empty((len(self.particles), 2))
        position[:, 0].fill(x)
        position[:, 1].fill(y)
        # # 1- We can take the difference between each particle new position and the measurement.
        # # In this case is the Euclidean Distance.
        distance = np.linalg.norm(self.particles - position, axis=1)
        # # 2- Particles which are closer to the real position have smaller Euclidean Distance,
        # # here we subtract the maximum distance in order to get the opposite
        # (particles close to the real position have an higher weight)
        max_distance = np.amax(distance)
        distance = np.add(-distance, max_distance)
        # # 3-Particles that best predict the measurement end up with the highest weight.
        self.weights.fill(1.0)  # reset the weight array
        self.weights *= distance
        # # 4- after the multiplication the sum of the weights won't be 1.
        # # Renormalize by dividing all the weights by the sum of all the weights.
        self.weights += 1.e-300  # avoid zeros
        self.weights /= sum(self.weights)  # normalize

    def update_gaussian(self, histo_distance):
        """Update the weights associated which each particle based on the (x,y) coords measured.
        Particles that closely match the measurements give an higher contribution.

        The position of the point at the next time step is predicted using the
        estimated speed along X and Y axis and adding Gaussian noise sampled
        from a distribution with MEAN=0.0 and STD=std. It is a linear model.
        @param x the position of the point in the X axis
        @param y the position of the point in the Y axis
        @param
        """
        # # 현재(T) PARTICLE and TARGET bhattacharyya 계산 후 gaussian으로 weight 반영
        # # 1- We can take the difference between each particle new position and the measurement.
        # # In this case is the bhattacharyya Distance.
        # # 2- Gaussian distribution
        sigma = 1
        distance = (1.0 / (np.sqrt(2.0 * np.pi) * sigma)) * np.exp((histo_distance-1.0) / 2.0 * sigma * sigma)
        self.weights *= distance
        # # 4- after the multiplication the sum of the weights won't be 1.
        # # Renormalize by dividing all the weights by the sum of all the weights.
        self.weights += 1.e-300  # avoid zeros
        self.weights /= sum(self.weights)  # normalize

    def resample(self, method='residual'):
        """Resample the particle based on their weights.

        The resempling (or importance sampling) draws with replacement N
        particles from the current set with a probability given by the current
        weights. The new set generated has always size N, and it is an
        approximation of the posterior distribution which represent the state
        of the particles at time t. The new set will have many duplicates
        corresponding to the particles with highest weight. The resampling
        solve a huge problem: after some iterations of the algorithm
        some particles are useless because they do not represent the point
        position anymore, eventually they will be too far away from the real position.
        The resample function removes useless particles and keep the
        useful ones. It is not necessary to resample at every epoch.
        If there are not new measurements then there is not any information
        from which the resample can benefit. To determine when to resample
        it can be used the returnParticlesContribution function.
        @param method the algorithm to use for the resampling.
            'multinomal' large weights are more likely to be selected [complexity O(n*log(n))]
            'residual' (default value) it ensures that the sampling is uniform across particles [complexity O(N)]
            'stratified' it divides the cumulative sum into N equal subsets, and then
                selects one particle randomly from each subset.
            'systematic' it divides the cumsum into N subsets, then add a random offset to all the susets
        """
        N = len(self.particles)
        if (method == 'multinomal'):
            # np.cumsum() computes the cumulative sum of an array.
            # Element one is the sum of elements zero and one,
            # element two is the sum of elements zero, one and two, etc.
            cumulative_sum = np.cumsum(self.weights)
            cumulative_sum[-1] = 1.  # avoid round-off error
            # np.searchsorted() Find indices where elements should be
            # inserted to maintain order. Here we generate random numbers
            # in the range [0.0, 1.0] and do a search to find the weight
            # that most closely matches that number. Large weights occupy
            # more space than low weights, so they will be more likely
            # to be selected.
            indices = np.searchsorted(cumulative_sum, np.random.uniform(low=0.0, high=1.0, size=N))
        elif (method == 'residual'):
            indices = np.zeros(N, dtype=np.int32)
            # take int(N*w) copies of each weight
            num_copies = (N * np.asarray(self.weights)).astype(int)
            k = 0
            for i in range(N):
                for _ in range(num_copies[i]):  # make n copies
                    indices[k] = i
                    k += 1
            # multinormial resample
            residual = self.weights - num_copies  # get fractional part
            residual /= sum(residual)  # normalize
            cumulative_sum = np.cumsum(residual)
            cumulative_sum[-1] = 1.  # ensures sum is exactly one
            indices[k:N] = np.searchsorted(cumulative_sum, np.random.random(N - k))
        elif (method == 'stratified'):
            # N subsets, chose a random position within each one
            # and generate a vector containing this positions
            positions = (np.random.random(N) + range(N)) / N
            # generate the empty indices vector
            indices = np.zeros(N, dtype=np.int32)
            # get the cumulative sum
            cumulative_sum = np.cumsum(self.weights)
            i, j = 0, 0
            while i < N:
                if positions[i] < cumulative_sum[j]:
                    indices[i] = j
                    i += 1
                else:
                    j += 1
        elif (method == 'systematic'):
            # make N subsets, choose positions with a random offset
            positions = (np.arange(N) + np.random.random()) / N
            indices = np.zeros(N, dtype=np.int32)
            cumulative_sum = np.cumsum(self.weights)
            i, j = 0, 0
            while i < N:
                if positions[i] < cumulative_sum[j]:
                    indices[i] = j
                    i += 1
                else:
                    j += 1
        else:
            raise ValueError("[DEEPGAZE] motion_tracking.py: the resempling method selected '" + str(
                method) + "' is not implemented")
        # Create a new set of particles by randomly choosing particles
        # from the current set according to their weights.
        self.particles[:] = self.particles[indices]  # resample according to indices
        self.weights[:] = self.weights[indices]
        # Normalize the new set of particles
        self.weights /= np.sum(self.weights)

    def returnParticlesContribution(self):
        """This function gives an estimation of the number of particles which are
        contributing to the probability distribution (also called the effective N).

        This function get the effective N value which is a good estimation for
        understanding when it is necessary to call a resampling step. When the particle
        are collapsing in one point only some of them are giving a contribution to
        the point estimation. If the value is less than N/2 then a resampling step
        should be called. A smaller value means a larger variance for the weights,
        hence more degeneracy
        @return get the effective N value.
        """
        return 1.0 / np.sum(np.square(self.weights))

    def returnParticlesCoordinates(self, index=-1):
        """It returns the (x,y) coord of a specific particle or of all particles.

        @param index the position in the particle array to return
            when negative it returns the whole particles array
        @return a single coordinate (x,y) or the entire array
        """
        if (index < 0):
            return self.particles.astype(int)
        else:
            return self.particles[index, :].astype(int)

    def copyParticleStatus(self, index=-1):
        """It returns the (x,y) coord of a specific particle or of all particles.

        @param index the position in the particle array to return
            when negative it returns the whole particles array
        @return a single coordinate (x,y) or the entire array
        """
        if (index < 0):
            return self.particles.astype(float), self.weights.astype(float)

    def backupParticle(self, prev_particle_pos, prev_particle_weights):
        """It returns the (x,y) coord of a specific particle or of all particles.

        @param index the position in the particle array to return
            when negative it returns the whole particles array
        @return a single coordinate (x,y) or the entire array
        """

        self.particles = prev_particle_pos
        self.weights = prev_particle_weights

        # print("backup pos: ", self.particles)
        # print("backup weights: ", self.weights)
        # print("backup pos: ", self.particles.shape)
        # print("backup weights: ", self.weights.shape)


    def drawParticles(self, frame, color= [0, 0, 255], radius=2):
        """Draw the particles on a frame and return it.

        @param frame the image to draw
        @param color the color in BGR format, ex: [0,0,255] (red)
        @param radius is the radius of the particles
        @return the frame with particles
        """
        for x_particle, y_particle in self.particles.astype(int):
            cv2.circle(frame, (x_particle, y_particle), radius, color, -1)  # RED: Particles
        cv2.imshow("particle", frame)

    def drawParticles2(self, frame, color= [255, 0, 0], radius=2):
        """Draw the particles on a frame and return it.

        @param frame the image to draw
        @param color the color in BGR format, ex: [0,0,255] (red)
        @param radius is the radius of the particles
        @return the frame with particles
        """
        for x_particle, y_particle in self.particles.astype(int):
            cv2.circle(frame, (x_particle, y_particle), radius, color, -1)  # RED: Particles
        cv2.imshow("particle", frame)


    # def particleImage(self, frame, face, particles, count, img_type):
    #     """Return the particles on a frame and return it.
    #
    #     @param frame the image
    #     @param color the color in BGR format, ex: [0,0,255] (red)
    #     @param radius is the radius of the particles
    #     @return the frame (only particle regions) with particles
    #     """
    #
    #     frame_copy = frame.copy()
    #
    #     if (img_type == 'HSV'):
    #         frame_copy = cv2.cvtColor(frame, cv2.COLOR_BGR2HSV)
    #     elif (img_type == 'GRAY'):
    #         frame_copy = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
    #     elif (img_type == 'RGB'):
    #         frame_copy = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
    #
    #     # # V S H --> H S V convert
    #     if (img_type == 'HSV'):
    #         crop_v, crop_s, crop_h = cv2.split(frame_copy)
    #         inverse_frame_copy = cv2.merge((crop_h, crop_s, crop_v))
    #         cv2.imshow("original_from_hsv", inverse_frame_copy)
    #         # cv2.imwrite("./canvas/%d_face.jpg" % count, frame_copy)
    #
    #     # # 우리는 HSV 이미지에서, 파티클 좌표에서 HSV 값만 추출하기를 원한다.
    #     # # 흰색 제거를 위해, 히스토그램 그릴 때 범위 0~255 로 설정해야 함 (0~256이 아니라)
    #     image = np.zeros(shape=frame_copy.shape, dtype=np.uint8)
    #     # # white-255,255,255, black-0,0,0
    #     image.fill(255)
    #
    #     # # [0] [1] [2]: channel value (R G B) or (H S V)
    #     # # 좌표값 접근 image[y,x]
    #     pixel_value = []
    #     for i in range(particles.shape[0]):
    #         # # [[x y]
    #         # #  [. .]]
    #         # print(particles[i])
    #         x_point = particles[i][0]
    #         y_point = particles[i][1]
    #         # print(x_point)
    #         # print(y_point)
    #         (h, s, v) = frame_copy[y_point, x_point]
    #         image[y_point, x_point] = (h, s, v)
    #         print(image[y_point, x_point])
    #
    #     # # Cropping (face region)
    #     x = int(face.box[0])
    #     y = int(face.box[1])
    #     w = int(face.box[2] - face.box[0])
    #     h = int(face.box[3] - face.box[1])
    #
    #     # # H S V --> V S H 상태임 다시 H S V로 변환 필요
    #     cropped_img = image[y:y + h, x:x + w]
    #     crop_v, crop_s, crop_h = cv2.split(cropped_img)
    #     inverse_cropped_img = cv2.merge((crop_h, crop_s, crop_v))
    #
    #     cv2.imshow("particle_img", inverse_cropped_img)
    #     # cv2.imwrite("./canvas/%d_face.jpg" % count, inverse_cropped_img)
    #
    #     return inverse_cropped_img
