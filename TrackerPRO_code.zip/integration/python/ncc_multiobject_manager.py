#!/usr/bin/python

# This is a simple example of a tracker implemented in Python. It uses OpenCV to compute the normalized cross correlation and find the best match with a template from a first frame.
# The demo is implemented using VOT Manager to show how a single object tracker can be quickly adapted to multi object scenarios.

import vot
import cv2
import math
import numpy as np
import datetime
import os

# deepgaze
from motion_tracking import ParticleFilter
from color_classification import HistogramColorClassifier

multiParticles = {}
prev_image = {}
prev_dist = {}
prev_flow_state = {}
next_flow_state = {}
template_image = {}
first_distance = {}
prev_rect = {}
prev_region = {}
final_region_pro = {}

NUM_PARTICLES = 5000
std = 3

def NCCTracker(image, region, idx):
    # # # # # # # # # # # # # Region: init. Rectangle[x,y, width, height] # # # # # # # # # # # # # # # # # # #
    # # # # # # # # # # # # # Image: frcleame 1 # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # #
    # # # # # # # # # # # # # 1번만 실행되는 코드 블록 # # # # # # # # # # # # # # # # # # # # # # # # # # # # # #

    # # # # # # # # # # # # # Defining the classifier # # # # # # # # # # # # # # # # # # # # # # # # # # # # # #
    my_classifier = HistogramColorClassifier(channels=[0, 1, 2], hist_size=[6, 6, 6],
                                             hist_range=[0, 128, 0, 128, 0, 128], hist_type='HSV')
        
    #image = cv2.imread(image, cv2.IMREAD_GRAYSCALE)
    image = cv2.imread(image, cv2.IMREAD_COLOR)
    prev_image[idx] = image
    window = max(region.width, region.height) * 2
    
    left = max(region.x, 0)
    top = max(region.y, 0)

    right = min(region.x + region.width, image.shape[1] - 1)
    bottom = min(region.y + region.height, image.shape[0] - 1)

    template = image[int(top):int(bottom), int(left):int(right)]
    template_width = right - left
    template_height = bottom - top

    template_image[0] = template
    template_image[1] = template_width
    template_image[2] = template_height
    
    position = [region.x + region.width / 2, region.y + region.height / 2]
    size = (region.width, region.height)

    # # # # # # # # # # # # Init. particles. (center pos.) # # # # # # # # # # # # # # # # # # # # # # # # # # # 
    particle_center_position = [position[0], position[1], size[0], size[1]]
   
    NUM_PARTICLES = int(region.width * region.height / 2)
    #print(NUM_PARTICLES)
    
    multiParticles[idx] = ParticleFilter(particle_center_position, NUM_PARTICLES, image.shape)
    #print(multiParticles[idx].returnParticlesCoordinates().shape)
    #print(multiParticles[idx].returnParticlesCoordinates())
    multi_particle_array = multiParticles[idx].returnParticlesCoordinates()
    
    # # # # # # # # # # # # Init. histo. dist. (particles vs region) # # # # # # # # # # # # # # # # # # # # # #            
    first_frame_dist = my_classifier.returnInitObjectParticleHistogramComparisonArray(
                        image, region, multi_particle_array, idx, method="bhattacharyya")
    first_distance[idx] = first_frame_dist         
    print("[F"+str(idx)+"] Init target vs particle histo dist: %.3f" % first_frame_dist)
    
    prev_dist[idx] = first_frame_dist
    prev_rect[idx] = [left, top, size[0], size[1]]

    def track(image, idx, frame_idx):
        img_content = image.split('/')[-3]
        # # # # # # # # # # (T) Frame 2~ image (*idx 개수) # # # # # # # # # # # # # # # # # # # # # # # # # # #
        # # # # # # # # # # position, size 값은 객체마다 저장됨 # # # # # # # # # # # # # # # # # # # # # # # # #
        #image = cv2.imread(image, cv2.IMREAD_GRAYSCALE)
        image = cv2.imread(image, cv2.IMREAD_COLOR)
        print("----------------------frame #"+str(frame_idx)+"--------------------------------")
        
        # # # # # # # # # # (T-1) frame particle vs object dist. # # # # # # # # # # # # # # # # # # # # # 
        prev_multi_particle = multiParticles[idx]
        prev_particle_array = prev_multi_particle.returnParticlesCoordinates()
        prev_particle_pos, prev_particle_weights = prev_multi_particle.copyParticleStatus()
        #print(prev_x, prev_y, size[0], size[1])

        prev_frame_dist = prev_dist[idx]
        
        # # # # # # # # # # (T-1 vs T) optical flow (Farneback) # # # # # # # # # # # # # # # # # # # # #         
        # prev, next: 이전, 이후 프레임
        # flow: 광학 흐름 계산 결과, 각 픽셀이 이동한 거리 (입력과 동일한 크기)
        # pyr_scale: 이미지 피라미드 스케일
        # levels: 이미지 피라미드 개수 
        # winsize: 평균 윈도 크기
        # iterations: 각 피라미드에서 반복할 횟수
        # poly_n: 다항식 근사를 위한 이웃 크기, 5 또는 7
        # poly_sigma: 다항식 근사에서 사용할 가우시안 시그마 (poly_n=5일 때는 1.1, poly_n=7일 때는 1.5)
        # flags: 연산 모드 (cv2.OPTFLOW_USE_INITAL_FLOW: flow 값을 초기 값으로 사용, cv2.OPTFLOW_FARNEBACK_GAUSSIAN: 박스 필터 대신 가우시안 필터 사용)

        prev_gray_image = cv2.cvtColor(prev_image[0], cv2.COLOR_BGR2GRAY)
        now_gray_image = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)

        # 추적 시작을 위한 코너 검출  ---①
        sift = cv2.SIFT_create(1000)
        keypoints = sift.detect(prev_gray_image, None)

        # img_sift = cv2.drawKeypoints(image, keypoints, None, flag=cv2.DRAW_MATCHES_FLAGS_DEFAULT)
        kp_shape = np.ones((len(keypoints), 1, 2))
        for i in range(len(keypoints)):
            pts_x = int(keypoints[i].pt[0])
            pts_y = int(keypoints[i].pt[1])
            kp_shape[i] = [pts_x, pts_y]

        # 옵티컬 플로우로 다음 프레임의 코너점  찾기 ---②
        #-- lucas kanade optical flow를 위한 매개변수
        lk_params = dict(winSize = (7, 7), maxLevel = 3, criteria = (cv2.TERM_CRITERIA_EPS | cv2.TERM_CRITERIA_COUNT, 10, 0.03))
        prevPt = np.float32(kp_shape)

        temp_prevPt = np.ones((len(prev_particle_pos), 1, 2))

        if len(prevPt) == 0:
            for i in range(len(prev_particle_pos)):
                temp_prevPt[i] = [prev_particle_pos[i][0], prev_particle_pos[i][1]]
            prev_flow_state[0] = temp_prevPt
            prevPt = np.float32(temp_prevPt)

        nextPt, status, err = cv2.calcOpticalFlowPyrLK(prev_gray_image, now_gray_image, prevPt, None, **lk_params)

        if len(nextPt) == 0:
            nextPt = prevPt

        # 대응점이 있는 코너, 움직인 코너 선별 ---③
        prevMv = prevPt[status == 1]
        nextMv = nextPt[status == 1]

        arr_prev = []
        arr_next = []

        # # center라 가정
        image_draw = image.copy()
        color = np.random.randint( 0, 255, (1000,3) )
        lines = None  #추적 선을 그릴 이미지 저장 변수
        lines = np.zeros_like(image)

        for i, (p, n) in enumerate(zip(prevMv, nextMv)):
            if i == 1000:
                break

            px, py = p.ravel()
            nx, ny = n.ravel()

            # 이전 코너와 새로운 코너에 선그리기 ---④
            cv2.line(lines, (int(px), int(py)), (int(nx), int(ny)), color[i].tolist(), 2)
            # 새로운 코너에 점 그리기
            cv2.circle(image_draw, (int(nx), int(ny)), 2, color[i].tolist(), -1)

            temp_next_arr = [int(nx), int(ny)]
            temp_prev_arr = [int(px), int(py)]

            arr_prev.append(temp_prev_arr)
            arr_next.append(temp_next_arr)

        image_draw = cv2.add(image_draw, lines)
        suffix = datetime.datetime.now().strftime("%H%M%S")
        if not os.path.exists("/mnt/nvme1/dhlee/PycharmProjects/vots2023/tests/test_sparse_flow/"+img_content+"/img/"):
            os.makedirs("/mnt/nvme1/dhlee/PycharmProjects/vots2023/tests/test_sparse_flow/"+img_content+"/img/")

        img_name = "/mnt/nvme1/dhlee/PycharmProjects/vots2023/tests/test_sparse_flow/"+img_content+"/img/opticlal"+str(int(frame_idx))+"_"+str(suffix)+".jpg"
        cv2.imwrite(img_name, image_draw)

        prev_flow_state[idx] = arr_prev
        next_flow_state[idx] = arr_next
        # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # #
                    
        prev_flow_state[idx] = prev_flow_state[0]
        next_flow_state[idx] = next_flow_state[0]        
        now_flow_x, now_flow_y = [], []
        prev_flow_x, prev_flow_y = [], []

        subframeCounter = 0
        reMatching = 0
        # # # # # # # # # # Particle filter (Circular uniform distribution) # # # # # # # # # # # # # # # # # # # # # # # # # #
        while subframeCounter < 3:
            print("--------------------Id {} - Subframe {}--------------------------------".format(idx, subframeCounter))

            # # # # # # # # # # (T) frame particle vs object dist. # # # # # # # # # # # # # # # # # # # # # # # # # # # # # #
            now_multi_particle = multiParticles[idx]
            now_particle_array_beR = now_multi_particle.returnParticlesCoordinates()

            # # # # # # # # # # (T_1) Predict # # # # # # # # # # # # # # # # # # # # # # # # # #  # # # # # # # # # # # # # #
            now_multi_particle.predict(x_velocity=0, y_velocity=0, std=std)

            # # # # # # # # # # (T_2) Estimate # # # # # # # # # # # # # # # # # # # # # # # # # #  # # # # # # # # # # # # #
            x_estimated_beR, y_estimated_beR, _, _ = now_multi_particle.estimate()

            # # # # # # # # # # (T_2_1) Estimated move x,y (before reSampling) # # # # # # # # # # # # # # # # # # # # # # # #
            now_left_beR = max(round(x_estimated_beR - prev_rect[idx][2] / 2), 0)
            now_top_beR = max(round(y_estimated_beR - prev_rect[idx][3] / 2), 0)
            now_right_beR = min(round(x_estimated_beR + prev_rect[idx][2] / 2), image.shape[1] - 1)
            now_bottom_beR = min(round(y_estimated_beR + prev_rect[idx][3] / 2), image.shape[0] - 1)

            #now_region_beR = [now_left_beR, now_top_beR, size[0], size[1]]
            now_region_beR = [now_left_beR, now_top_beR, prev_rect[idx][2], prev_rect[idx][3]]
            #print(now_region_beR)

            now_frame_dist_beR = my_classifier.returnAllObjectParticleHistogramComparisonArray(
                image, now_region_beR, now_particle_array_beR, idx, str(subframeCounter), int(frame_idx), img_content, 1, method="bhattacharyya")
            print("[T] PARTICLE and TARGET HISTO. DISTANCE BeR: %.3f" % now_frame_dist_beR)

            # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # #
            print("[T-1] PREV_FRAME_DISTANCE: %.3f" % prev_frame_dist)
            print("[T] NOW_FRAME_DISTANCE: %.3f" % now_frame_dist_beR)
            print("[T]-[T-1]: %.3f" % abs(now_frame_dist_beR - prev_frame_dist))
            # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # #

            if now_frame_dist_beR - prev_frame_dist > 0.1 or now_frame_dist_beR > 0.2:
                multiParticles[idx].backupParticle(prev_particle_pos, prev_particle_weights)
                subframeCounter += 1
                if subframeCounter == 2:
                    reMatching = 1
                    break

            # # # # # # # # # # (T_3) Update weights (input: trust x,y position) # # # # # # # # # # # # # # # # # # # # # # #
            for key in next_flow_state[idx]:
                xdx = key[0]
                ydy = key[1]

                # # # # # # # # # # next_flow find good position
                if xdx >= now_left_beR and xdx <= now_right_beR and ydy >= now_top_beR and ydy <= now_bottom_beR:
                    now_flow_x.append(xdx)
                    now_flow_y.append(ydy)

            # # # # # # # # # # now_flow find good position
            if len(now_flow_x) or len(now_flow_y) > 0:
                now_flow_mean_x, now_flow_mean_y = int(np.mean(now_flow_x)), int(np.mean(now_flow_y))
                print("Update_Prev flow pos: ", now_flow_mean_x - prev_rect[idx][2], now_flow_mean_y - prev_rect[idx][3])
                now_multi_particle.update(now_flow_mean_x, now_flow_mean_y)

            # # # # # # # # # # now_flow find not good position
            else:
                now_flow_mean_x, now_flow_mean_y = x_estimated_beR, y_estimated_beR
                print("Update particle pos: ", now_flow_mean_x - prev_rect[idx][2], now_flow_mean_y - prev_rect[idx][3])
                now_multi_particle.update(now_flow_mean_x, now_flow_mean_y)

            # # # # # # # # # # (T_3) Resample # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # #
            now_multi_particle.resample()

            # # # # # # # # # # (T_4) Really move # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # #
            now_x_estimated, now_y_estimated, _, _ = now_multi_particle.estimate()

            left = max(round(now_x_estimated - prev_rect[idx][2] / 2), 0)
            top = max(round(now_y_estimated - prev_rect[idx][3] / 2), 0)

            right = min(round(now_x_estimated + prev_rect[idx][2] / 2), image.shape[1] - 1)
            bottom = min(round(now_y_estimated + prev_rect[idx][3] / 2), image.shape[0] - 1)

            # # # # # # # # # # Particle success # # # # # # # # # # # # # # # # # # # # # # # # # #
            now_particle_array = now_multi_particle.returnParticlesCoordinates()
            now_particle_pos, now_particle_weights = now_multi_particle.copyParticleStatus()

            contraction_range_x = now_particle_pos[:, 0]
            contraction_range_y = now_particle_pos[:, 1]

            c_min_x = max(np.min(contraction_range_x), 0)
            c_min_y = max(np.min(contraction_range_y), 0)
            c_max_x = min(np.max(contraction_range_x), image.shape[1] - 1)
            c_max_y = min(np.max(contraction_range_y), image.shape[0] - 1)

            c_width = int(abs(c_max_x - c_min_x))
            c_height = int(abs(c_max_y - c_min_y))
            c_center_x = int((c_max_x - c_min_x)/2)
            c_center_y = int((c_max_y - c_min_y)/2)
            #print(c_min_x, c_min_y, c_max_x, c_max_y)
            print("[T]: Contraction_WH", c_width, c_height)

            d_min_x = max(int(c_center_x-c_width), 0)
            d_min_y = max(int(c_center_y-c_height), 0)
            d_max_x = min(int(c_center_x+c_width), image.shape[1] - 1)
            d_max_y = min(int(c_center_y+c_height), image.shape[0] - 1)
            d_width = int(abs(d_max_x - d_min_x))
            d_height = int(abs(d_max_y - d_min_y))
            d_center_x = int((d_max_x - d_min_x) / 2)
            d_center_y = int((d_max_y - d_min_y) / 2)
            #print(d_min_x, d_min_y, d_max_x, d_max_y)
            print("[T]: Dilation_WH: ", d_width, d_height)

            # # Too much contraction or dilation
            if c_width <= int(template_image[1]*0.5) or c_height <= int(template_image[2]*0.5):
                prev_rect[idx][0] = int(now_x_estimated)
                prev_rect[idx][1] = int(now_y_estimated)
                reMatching = 1
                break
            elif d_width >= int(template_image[1]*2) or d_height >= int(template_image[2]*2):
                prev_rect[idx][0] = int(now_x_estimated)
                prev_rect[idx][1] = int(now_y_estimated)
                reMatching = 1
                break

            c_target = image[int(c_min_y):int(c_max_y), int(c_min_x):int(c_max_x)]
            d_target = image[int(d_min_y):int(d_max_y), int(d_min_x):int(d_max_x)]

            # # # # # # # # # # now_obj vs init_obj hist. dist. # # # # # # # # # # # # # # # # # # # # # # # # # #
            c_object_histo_distance = my_classifier.returnObjectoObjectDistance(c_target, template_image[0], idx, int(frame_idx), method="bhattacharyya")
            d_object_histo_distance = my_classifier.returnObjectoObjectDistance(d_target, template_image[0], idx,
                                                                                int(frame_idx), method="bhattacharyya")
            print("[T] Contraction_dist: ", c_object_histo_distance)
            print("[T] Dilation_dist: ", d_object_histo_distance)

            # # Final contraction area (lower is good)
            if c_object_histo_distance <= d_object_histo_distance:
                # # Quality contraction or dilation area
                if c_object_histo_distance - first_distance[idx] > 0.1:
                    prev_rect[idx][0] = int(now_x_estimated)
                    prev_rect[idx][1] = int(now_y_estimated)
                    reMatching = 1
                    break

                # # Correct contraction
                left = max(int(c_min_x), 0)
                top = max(int(c_min_y), 0)
                now_region = [left, top, c_width, c_height]
                multiParticles[idx].backupParticle(now_particle_pos, now_particle_weights)

                print("GParticle: ", vot.Rectangle(now_region[0], now_region[1], now_region[2], now_region[3]))
                now_frame_dist = my_classifier.returnObjectParticleHistogramComparisonArray(
                    image, now_region, now_particle_array, idx, int(frame_idx), img_content, 2, method="bhattacharyya")
                prev_dist[idx] = now_frame_dist
                prev_rect[idx] = [left, top, c_width, c_height]
                reMatching = 0
                break

            # # Final dilation area (lower is good)
            elif c_object_histo_distance > d_object_histo_distance:
                if d_object_histo_distance - first_distance[idx] > 0.1:
                    prev_rect[idx][0] = int(now_x_estimated)
                    prev_rect[idx][1] = int(now_y_estimated)
                    reMatching = 1
                    break

                # # Correct contraction
                left = max(int(d_min_x), 0)
                top = max(int(d_min_y), 0)
                now_region = [left, top, d_width, d_height]

                NUM_PARTICLES = int(d_width * d_height / 2)
                dilation_center_position = [d_center_x, d_center_y, now_region[2], now_region[3]]

                multiParticles[idx] = ParticleFilter(dilation_center_position, NUM_PARTICLES, image.shape)
                now_particle_array = now_multi_particle.returnParticlesCoordinates()
                now_particle_pos, now_particle_weights = now_multi_particle.copyParticleStatus()

                multiParticles[idx].backupParticle(now_particle_pos, now_particle_weights)

                print("GParticle: ",
                      vot.Rectangle(now_region[0], now_region[1], now_region[2], now_region[3]))
                now_frame_dist = my_classifier.returnObjectParticleHistogramComparisonArray(
                    image, now_region, now_particle_array, idx, int(frame_idx), img_content, 3,
                    method="bhattacharyya")
                prev_dist[idx] = now_frame_dist
                prev_rect[idx] = [left, top, d_width, d_height]
                reMatching = 0
                break

        if reMatching == 1:
            # # # # # # # # # # failure region # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # #
            # # extension for matching area
            left = max(round(prev_rect[idx][0] - float(window) / 2), 0)
            top = max(round(prev_rect[idx][1] - float(window) / 2), 0)

            right = min(round(prev_rect[idx][0] + float(window) / 2), image.shape[1] - 1)
            bottom = min(round(prev_rect[idx][1] + float(window) / 2), image.shape[0] - 1)

            # T. M. ==> extend box size for matching
            if right - left < template.shape[1] or bottom - top < template.shape[0]:
                return vot.Rectangle(prev_rect[idx][0] + size[0] / 2, prev_rect[idx][1] + size[1] / 2, size[0], size[1])

            cut = image[int(top):int(bottom), int(left):int(right)]

            matches = cv2.matchTemplate(cut, template, cv2.TM_CCOEFF_NORMED)
            # # # # # # # # # # find highest matches condition # # # # # # # # # # # # # # # # # # # # # # # # # #
            min_val, max_val, min_loc, max_loc = cv2.minMaxLoc(matches)
            print(min_val, max_val, min_loc, max_loc)

            position[0] = left + max_loc[0] + float(size[0]) / 2
            position[1] = top + max_loc[1] + float(size[1]) / 2

            # An example of how to use the response value threshold to report object not found
            if max_val < 0.5:
                print("NotMatching: ")
                return vot.Empty()
            
            print("Final_Matching: ", vot.Rectangle(left + max_loc[0], top + max_loc[1], size[0], size[1]))

            match_center_position = [position[0], position[1], size[0], size[1]]
            NUM_PARTICLES = int(template.shape[1] * template.shape[0] / 2)

            multiParticles[idx] = ParticleFilter(match_center_position, NUM_PARTICLES, image.shape)
            match_particle_array = multiParticles[idx].returnParticlesCoordinates()

            final_match_left = left + max_loc[0]
            final_match_top = top + max_loc[1]

            final_region_pro[idx] = [final_match_left, final_match_top, size[0], size[1]]
            match_frame_dist = my_classifier.returnObjectParticleHistogramComparisonArray(
                image, final_region_pro[idx], match_particle_array, idx, int(frame_idx), img_content, 4, method="bhattacharyya")
            print("[T] MATCHED OBJECT and TEMPLATE HISTO. DISTANCE: %.3f" % match_frame_dist)

            prev_dist[idx] = match_frame_dist
            prev_image[idx] = image
            prev_rect[idx] = [final_match_left, final_match_top, size[0], size[1]]

            return vot.Rectangle(final_match_left, final_match_top, size[0], size[1])

        # # # # # # # # # # Success particle matching # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # #
        prev_image[idx] = image
        final_region_pro[idx] = [int(prev_rect[idx][0]), int(prev_rect[idx][1]), int(prev_rect[idx][2]), int(prev_rect[idx][3])]
        return vot.Rectangle(final_region_pro[idx][0], final_region_pro[idx][1], final_region_pro[idx][2], final_region_pro[idx][3])

    return track

if __name__ == "__main__":
    print(vot.__file__)
    manager = vot.VOTManager(NCCTracker, "rectangle")
    manager.run()
