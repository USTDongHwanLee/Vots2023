[1] We used the cv2.imwrite function to visualize the results. Please change the path or remove the path.
   1) ncc_multiobject_manager.py 
      1. line 175~179

   2) color_classification.py 
      1. line 163~172
      2. line 248~290
      3. line 366~375
      
[2] Python code for the repropagation code did not exist, so we implemented it ourselves.

[3] We updated the code for particle generation and histogram distance calculation.
      3.1. motion_tracking.py
      3.2. color_classification.py
     
https://github.com/mpatacchiola/deepgaze/tree/master/deepgaze

